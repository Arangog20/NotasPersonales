<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Categoria"%>
<%
    Categoria categoria = (Categoria) request.getAttribute("categoria");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Categoría | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/editar.css">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Edición de categorías</span>
                <h1 class="title-page">Editar Categoría</h1>
                <p class="subtitle-page">
                    Actualiza la información de la categoría para mantener organizada la clasificación de notas.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/categorias?accion=listar" class="btn btn-secondary">Volver al Listado</a>
            </div>
        </div>

        <div class="edit-card">
            <div class="edit-header">
                <h2>Información de la categoría</h2>
                <p>Modifica los datos del registro seleccionado.</p>
            </div>

            <form action="${pageContext.request.contextPath}/categorias" method="post">
                <input type="hidden" name="accion" value="actualizar">
                <input type="hidden" name="id" value="<%= categoria.getId() %>">

                <div class="edit-grid">
                    <div class="edit-group">
                        <label for="nombre">Nombre</label>
                        <input class="edit-control" type="text" id="nombre" name="nombre" value="<%= categoria.getNombre() %>" required>
                    </div>

                    <div class="edit-group">
                        <label for="estado">Estado</label>
                        <select class="edit-control" id="estado" name="estado">
                            <option value="ACTIVA" <%= "ACTIVA".equals(categoria.getEstado()) ? "selected" : "" %>>ACTIVA</option>
                            <option value="INACTIVA" <%= "INACTIVA".equals(categoria.getEstado()) ? "selected" : "" %>>INACTIVA</option>
                        </select>
                    </div>

                    <div class="edit-group edit-group-full">
                        <label for="descripcion">Descripción</label>
                        <input class="edit-control" type="text" id="descripcion" name="descripcion" value="<%= categoria.getDescripcion() != null ? categoria.getDescripcion() : "" %>">
                    </div>

                    <div class="edit-group">
                        <label for="color">Color</label>
                        <input class="edit-control" type="text" id="color" name="color" value="<%= categoria.getColor() != null ? categoria.getColor() : "" %>">
                    </div>
                </div>

                <div class="form-actions" style="margin-top: 24px;">
                    <button type="submit" class="btn btn-primary">Actualizar Categoría</button>
                    <a href="${pageContext.request.contextPath}/categorias?accion=listar" class="btn btn-cancel">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>