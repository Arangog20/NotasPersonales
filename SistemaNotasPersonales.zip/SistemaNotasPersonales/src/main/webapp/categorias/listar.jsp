<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Categoria"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Categorías | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/listar.css">
</head>
<body>
    <%
        String mensaje = request.getParameter("mensaje");
        String tipo = request.getParameter("tipo");
        List<Categoria> listaCategorias = (List<Categoria>) request.getAttribute("listaCategorias");
    %>

    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Organización visual</span>
                <h1 class="title-page">Categorías</h1>
                <p class="subtitle-page">
                    Administra las categorías disponibles para clasificar las notas personales del sistema.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/categorias/crear.jsp" class="btn btn-primary">Nueva Categoría</a>
                <a href="${pageContext.request.contextPath}/index.html" class="btn btn-secondary">Volver al Inicio</a>
            </div>
        </div>

        <% if (mensaje != null && !mensaje.trim().isEmpty()) { %>
            <div class="alert <%= "success".equals(tipo) ? "alert-success" : "alert-error" %>">
                <%= mensaje %>
            </div>
        <% } %>

        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Color</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (listaCategorias != null && !listaCategorias.isEmpty()) {
                        for (Categoria c : listaCategorias) { %>
                        <tr>
                            <td><%= c.getId() %></td>
                            <td><strong><%= c.getNombre() %></strong></td>
                            <td><%= c.getDescripcion() != null ? c.getDescripcion() : "-" %></td>
                            <td>
                                <div style="display:flex; align-items:center; justify-content:center; gap:10px;">
                                    <span style="width:18px; height:18px; border-radius:50%; display:inline-block; background:<%= c.getColor() %>; border:1px solid #ddd;"></span>
                                    <span><%= c.getColor() %></span>
                                </div>
                            </td>
                            <td>
                                <span class="badge badge-<%= c.getEstado().toLowerCase() %>">
                                    <%= c.getEstado() %>
                                </span>
                            </td>
                            <td>
                                <div class="cell-actions">
                                    <a class="btn btn-edit" href="${pageContext.request.contextPath}/categorias?accion=editar&id=<%= c.getId() %>">Editar</a>
                                    <a class="btn btn-delete" href="${pageContext.request.contextPath}/categorias?accion=eliminar&id=<%= c.getId() %>"
                                       onclick="return confirm('¿Deseas eliminar esta categoría?');">Eliminar</a>
                                </div>
                            </td>
                        </tr>
                    <%  }
                    } else { %>
                        <tr>
                            <td colspan="6" class="empty-table">No hay categorías registradas.</td>
                        </tr>
                    <% } %>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>