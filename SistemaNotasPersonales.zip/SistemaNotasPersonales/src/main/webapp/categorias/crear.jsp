<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nueva Categoría | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/crear.css">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Nueva clasificación</span>
                <h1 class="title-page">Crear Categoría</h1>
                <p class="subtitle-page">
                    Registra una nueva categoría para organizar mejor las notas dentro del sistema.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/categorias?accion=listar" class="btn btn-secondary">Volver al Listado</a>
            </div>
        </div>

        <div class="form-card">
            <div class="form-header">
                <h2>Información de la categoría</h2>
                <p>Completa los campos necesarios para registrar una nueva categoría.</p>
            </div>

            <form action="${pageContext.request.contextPath}/categorias" method="post">
                <input type="hidden" name="accion" value="guardar">

                <div class="form-grid">
                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input class="form-control" type="text" id="nombre" name="nombre" placeholder="Ej: Trabajo" required>
                    </div>

                    <div class="form-group">
                        <label for="estado">Estado</label>
                        <select class="form-control" id="estado" name="estado" required>
                            <option value="ACTIVA">ACTIVA</option>
                            <option value="INACTIVA">INACTIVA</option>
                        </select>
                    </div>

                    <div class="form-group form-group-full">
                        <label for="descripcion">Descripción</label>
                        <input class="form-control" type="text" id="descripcion" name="descripcion" placeholder="Describe el propósito de esta categoría">
                    </div>

                    <div class="form-group">
                        <label for="color">Color</label>
                        <input class="form-control" type="text" id="color" name="color" value="#3498db" placeholder="#3498db">
                    </div>
                </div>

                <div class="form-actions" style="margin-top: 24px;">
                    <button type="submit" class="btn btn-primary">Guardar Categoría</button>
                    <a href="${pageContext.request.contextPath}/categorias?accion=listar" class="btn btn-cancel">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>