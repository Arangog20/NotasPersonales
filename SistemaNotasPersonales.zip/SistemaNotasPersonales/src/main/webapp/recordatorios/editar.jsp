<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.time.format.DateTimeFormatter"%>
<%@page import="java.util.List"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Nota"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Recordatorio"%>
<%
    Recordatorio recordatorio = (Recordatorio) request.getAttribute("recordatorio");
    List<Nota> listaNotas = (List<Nota>) request.getAttribute("listaNotas");
    String fechaFormateada = "";
    if (recordatorio.getFechaRecordatorio() != null) {
        fechaFormateada = recordatorio.getFechaRecordatorio().format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm"));
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Recordatorio | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/editar.css">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Seguimiento programado</span>
                <h1 class="title-page">Editar Recordatorio</h1>
                <p class="subtitle-page">
                    Ajusta la fecha, el mensaje y el estado del recordatorio seleccionado.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/recordatorios?accion=listar" class="btn btn-secondary">Volver al Listado</a>
            </div>
        </div>

        <div class="edit-card">
            <div class="edit-header">
                <h2>Información del recordatorio</h2>
                <p>Actualiza los datos necesarios del recordatorio seleccionado.</p>
            </div>

            <form action="${pageContext.request.contextPath}/recordatorios" method="post">
                <input type="hidden" name="accion" value="actualizar">
                <input type="hidden" name="id" value="<%= recordatorio.getId() %>">

                <div class="edit-grid">
                    <div class="edit-group">
                        <label for="notaId">Nota</label>
                        <select class="edit-control" id="notaId" name="notaId" required>
                            <% if (listaNotas != null) {
                                for (Nota n : listaNotas) { %>
                                <option value="<%= n.getId() %>" <%= n.getId() == recordatorio.getNotaId() ? "selected" : "" %>>
                                    <%= n.getTitulo() %>
                                </option>
                            <%  }
                            } %>
                        </select>
                    </div>

                    <div class="edit-group">
                        <label for="fechaRecordatorio">Fecha y hora</label>
                        <input class="edit-control" type="datetime-local" id="fechaRecordatorio" name="fechaRecordatorio" value="<%= fechaFormateada %>" required>
                    </div>

                    <div class="edit-group edit-group-full">
                        <label for="mensaje">Mensaje</label>
                        <input class="edit-control" type="text" id="mensaje" name="mensaje" value="<%= recordatorio.getMensaje() %>" required>
                    </div>

                    <div class="edit-group">
                        <label for="estado">Estado</label>
                        <select class="edit-control" id="estado" name="estado">
                            <option value="PENDIENTE" <%= "PENDIENTE".equals(recordatorio.getEstado()) ? "selected" : "" %>>PENDIENTE</option>
                            <option value="ENVIADO" <%= "ENVIADO".equals(recordatorio.getEstado()) ? "selected" : "" %>>ENVIADO</option>
                            <option value="CANCELADO" <%= "CANCELADO".equals(recordatorio.getEstado()) ? "selected" : "" %>>CANCELADO</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions" style="margin-top: 24px;">
                    <button type="submit" class="btn btn-primary">Actualizar Recordatorio</button>
                    <a href="${pageContext.request.contextPath}/recordatorios?accion=listar" class="btn btn-cancel">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>