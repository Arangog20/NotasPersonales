<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Recordatorio"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Recordatorios | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/listar.css">
</head>
<body>
    <%
        String mensaje = request.getParameter("mensaje");
        String tipo = request.getParameter("tipo");
        List<Recordatorio> listaRecordatorios = (List<Recordatorio>) request.getAttribute("listaRecordatorios");
    %>

    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Planificación y seguimiento</span>
                <h1 class="title-page">Recordatorios</h1>
                <p class="subtitle-page">
                    Consulta los recordatorios asociados a las notas y mantén el seguimiento de tus tareas.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/recordatorios?accion=nuevo" class="btn btn-primary">Nuevo Recordatorio</a>
                <a href="${pageContext.request.contextPath}/index.html" class="btn btn-secondary">Volver al Inicio</a>
            </div>
        </div>

        <% if (mensaje != null && !mensaje.trim().isEmpty()) { %>
            <div class="alert <%= "success".equals(tipo) ? "alert-success" : "alert-error" %>">
                <%= mensaje %>
            </div>
        <% } %>

        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nota ID</th>
                        <th>Fecha</th>
                        <th>Mensaje</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (listaRecordatorios != null && !listaRecordatorios.isEmpty()) {
                        for (Recordatorio r : listaRecordatorios) { %>
                        <tr>
                            <td><%= r.getId() %></td>
                            <td><%= r.getNotaId() %></td>
                            <td><%= r.getFechaRecordatorio() %></td>
                            <td><%= r.getMensaje() %></td>
                            <td>
                                <span class="badge badge-<%= r.getEstado().toLowerCase() %>">
                                    <%= r.getEstado() %>
                                </span>
                            </td>
                            <td>
                                <div class="cell-actions">
                                    <a class="btn btn-edit" href="${pageContext.request.contextPath}/recordatorios?accion=editar&id=<%= r.getId() %>">Editar</a>
                                    <a class="btn btn-delete" href="${pageContext.request.contextPath}/recordatorios?accion=eliminar&id=<%= r.getId() %>"
                                       onclick="return confirm('¿Deseas eliminar este recordatorio?');">Eliminar</a>
                                </div>
                            </td>
                        </tr>
                    <%  }
                    } else { %>
                        <tr>
                            <td colspan="6" class="empty-table">No hay recordatorios registrados.</td>
                        </tr>
                    <% } %>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>