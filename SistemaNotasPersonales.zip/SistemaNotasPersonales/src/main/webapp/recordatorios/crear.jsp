<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Nota"%>
<%
    List<Nota> listaNotas = (List<Nota>) request.getAttribute("listaNotas");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nuevo Recordatorio | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/crear.css">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Planificación personal</span>
                <h1 class="title-page">Crear Recordatorio</h1>
                <p class="subtitle-page">
                    Programa un recordatorio asociado a una nota para dar seguimiento a tus pendientes.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/recordatorios?accion=listar" class="btn btn-secondary">Volver al Listado</a>
            </div>
        </div>

        <div class="form-card">
            <div class="form-header">
                <h2>Información del recordatorio</h2>
                <p>Completa los campos necesarios para registrar un nuevo recordatorio.</p>
            </div>

            <form action="${pageContext.request.contextPath}/recordatorios" method="post">
                <input type="hidden" name="accion" value="guardar">

                <div class="form-grid">
                    <div class="form-group">
                        <label for="notaId">Nota</label>
                        <select class="form-control" id="notaId" name="notaId" required>
                            <% if (listaNotas != null) {
                                for (Nota n : listaNotas) { %>
                                <option value="<%= n.getId() %>"><%= n.getTitulo() %></option>
                            <%  }
                            } %>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="fechaRecordatorio">Fecha y hora</label>
                        <input class="form-control" type="datetime-local" id="fechaRecordatorio" name="fechaRecordatorio" required>
                    </div>

                    <div class="form-group form-group-full">
                        <label for="mensaje">Mensaje</label>
                        <input class="form-control" type="text" id="mensaje" name="mensaje" placeholder="Escribe el mensaje del recordatorio" required>
                    </div>

                    <div class="form-group">
                        <label for="estado">Estado</label>
                        <select class="form-control" id="estado" name="estado" required>
                            <option value="PENDIENTE">PENDIENTE</option>
                            <option value="ENVIADO">ENVIADO</option>
                            <option value="CANCELADO">CANCELADO</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions" style="margin-top: 24px;">
                    <button type="submit" class="btn btn-primary">Guardar Recordatorio</button>
                    <a href="${pageContext.request.contextPath}/recordatorios?accion=listar" class="btn btn-cancel">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>