<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Usuario"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Categoria"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Nota"%>
<%
    Nota nota = (Nota) request.getAttribute("nota");
    List<Usuario> listaUsuarios = (List<Usuario>) request.getAttribute("listaUsuarios");
    List<Categoria> listaCategorias = (List<Categoria>) request.getAttribute("listaCategorias");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Nota | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/editar.css">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Edición de contenido</span>
                <h1 class="title-page">Editar Nota</h1>
                <p class="subtitle-page">
                    Ajusta el contenido, prioridad y estado de la nota seleccionada.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/notas?accion=listar" class="btn btn-secondary">Volver al Listado</a>
            </div>
        </div>

        <div class="edit-card">
            <div class="edit-header">
                <h2>Información de la nota</h2>
                <p>Actualiza los datos necesarios de la nota registrada.</p>
            </div>

            <form action="${pageContext.request.contextPath}/notas" method="post">
                <input type="hidden" name="accion" value="actualizar">
                <input type="hidden" name="id" value="<%= nota.getId() %>">

                <div class="edit-grid">
                    <div class="edit-group">
                        <label for="usuarioId">Usuario</label>
                        <select class="edit-control" id="usuarioId" name="usuarioId" required>
                            <% if (listaUsuarios != null) {
                                for (Usuario u : listaUsuarios) { %>
                                <option value="<%= u.getId() %>" <%= u.getId() == nota.getUsuarioId() ? "selected" : "" %>>
                                    <%= u.getNombre() %> <%= u.getApellido() %>
                                </option>
                            <%  }
                            } %>
                        </select>
                    </div>

                    <div class="edit-group">
                        <label for="categoriaId">Categoría</label>
                        <select class="edit-control" id="categoriaId" name="categoriaId" required>
                            <% if (listaCategorias != null) {
                                for (Categoria c : listaCategorias) { %>
                                <option value="<%= c.getId() %>" <%= c.getId() == nota.getCategoriaId() ? "selected" : "" %>>
                                    <%= c.getNombre() %>
                                </option>
                            <%  }
                            } %>
                        </select>
                    </div>

                    <div class="edit-group edit-group-full">
                        <label for="titulo">Título</label>
                        <input class="edit-control" type="text" id="titulo" name="titulo" value="<%= nota.getTitulo() %>" required>
                    </div>

                    <div class="edit-group edit-group-full">
                        <label for="contenido">Contenido</label>
                        <textarea class="edit-control" id="contenido" name="contenido" rows="6" required><%= nota.getContenido() %></textarea>
                    </div>

                    <div class="edit-group">
                        <label for="prioridad">Prioridad</label>
                        <select class="edit-control" id="prioridad" name="prioridad">
                            <option value="BAJA" <%= "BAJA".equals(nota.getPrioridad()) ? "selected" : "" %>>BAJA</option>
                            <option value="MEDIA" <%= "MEDIA".equals(nota.getPrioridad()) ? "selected" : "" %>>MEDIA</option>
                            <option value="ALTA" <%= "ALTA".equals(nota.getPrioridad()) ? "selected" : "" %>>ALTA</option>
                        </select>
                    </div>

                    <div class="edit-group">
                        <label for="estado">Estado</label>
                        <select class="edit-control" id="estado" name="estado">
                            <option value="ACTIVA" <%= "ACTIVA".equals(nota.getEstado()) ? "selected" : "" %>>ACTIVA</option>
                            <option value="ARCHIVADA" <%= "ARCHIVADA".equals(nota.getEstado()) ? "selected" : "" %>>ARCHIVADA</option>
                            <option value="ELIMINADA" <%= "ELIMINADA".equals(nota.getEstado()) ? "selected" : "" %>>ELIMINADA</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions" style="margin-top: 24px;">
                    <button type="submit" class="btn btn-primary">Actualizar Nota</button>
                    <a href="${pageContext.request.contextPath}/notas?accion=listar" class="btn btn-cancel">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>