<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Nota"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Notas | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/listar.css">
</head>
<body>
    <%
        String mensaje = request.getParameter("mensaje");
        String tipo = request.getParameter("tipo");
        List<Nota> listaNotas = (List<Nota>) request.getAttribute("listaNotas");
    %>

    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Gestión de contenido</span>
                <h1 class="title-page">Notas</h1>
                <p class="subtitle-page">
                    Visualiza, organiza y administra todas las notas creadas en el sistema.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/notas?accion=nuevo" class="btn btn-primary">Nueva Nota</a>
                <a href="${pageContext.request.contextPath}/index.html" class="btn btn-secondary">Volver al Inicio</a>
            </div>
        </div>

        <% if (mensaje != null && !mensaje.trim().isEmpty()) { %>
            <div class="alert <%= "success".equals(tipo) ? "alert-success" : "alert-error" %>">
                <%= mensaje %>
            </div>
        <% } %>

        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Usuario ID</th>
                        <th>Categoría ID</th>
                        <th>Título</th>
                        <th>Contenido</th>
                        <th>Prioridad</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (listaNotas != null && !listaNotas.isEmpty()) {
                        for (Nota n : listaNotas) { %>
                        <tr>
                            <td><%= n.getId() %></td>
                            <td><%= n.getUsuarioId() %></td>
                            <td><%= n.getCategoriaId() %></td>
                            <td><strong><%= n.getTitulo() %></strong></td>
                            <td>
                                <%= n.getContenido() != null && n.getContenido().length() > 60
                                    ? n.getContenido().substring(0, 60) + "..."
                                    : n.getContenido() %>
                            </td>
                            <td>
                                <span class="badge badge-<%= n.getPrioridad().toLowerCase() %>">
                                    <%= n.getPrioridad() %>
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-<%= n.getEstado().toLowerCase() %>">
                                    <%= n.getEstado() %>
                                </span>
                            </td>
                            <td>
                                <div class="cell-actions">
                                    <a class="btn btn-edit" href="${pageContext.request.contextPath}/notas?accion=editar&id=<%= n.getId() %>">Editar</a>
                                    <a class="btn btn-delete" href="${pageContext.request.contextPath}/notas?accion=eliminar&id=<%= n.getId() %>"
                                       onclick="return confirm('¿Deseas eliminar esta nota?');">Eliminar</a>
                                </div>
                            </td>
                        </tr>
                    <%  }
                    } else { %>
                        <tr>
                            <td colspan="8" class="empty-table">No hay notas registradas.</td>
                        </tr>
                    <% } %>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>