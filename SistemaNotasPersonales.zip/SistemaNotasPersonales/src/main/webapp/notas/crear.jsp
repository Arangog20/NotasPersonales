<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Usuario"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Categoria"%>
<%
    List<Usuario> listaUsuarios = (List<Usuario>) request.getAttribute("listaUsuarios");
    List<Categoria> listaCategorias = (List<Categoria>) request.getAttribute("listaCategorias");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nueva Nota | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/crear.css">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Nuevo contenido</span>
                <h1 class="title-page">Crear Nota</h1>
                <p class="subtitle-page">
                    Registra una nueva nota y asígnala a un usuario y a una categoría.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/notas?accion=listar" class="btn btn-secondary">Volver al Listado</a>
            </div>
        </div>

        <div class="form-card">
            <div class="form-header">
                <h2>Información de la nota</h2>
                <p>Completa los siguientes datos para registrar una nueva nota en el sistema.</p>
            </div>

            <form action="${pageContext.request.contextPath}/notas" method="post">
                <input type="hidden" name="accion" value="guardar">

                <div class="form-grid">
                    <div class="form-group">
                        <label for="usuarioId">Usuario</label>
                        <select class="form-control" id="usuarioId" name="usuarioId" required>
                            <% if (listaUsuarios != null) {
                                for (Usuario u : listaUsuarios) { %>
                                <option value="<%= u.getId() %>"><%= u.getNombre() %> <%= u.getApellido() %></option>
                            <%  }
                            } %>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="categoriaId">Categoría</label>
                        <select class="form-control" id="categoriaId" name="categoriaId" required>
                            <% if (listaCategorias != null) {
                                for (Categoria c : listaCategorias) { %>
                                <option value="<%= c.getId() %>"><%= c.getNombre() %></option>
                            <%  }
                            } %>
                        </select>
                    </div>

                    <div class="form-group form-group-full">
                        <label for="titulo">Título</label>
                        <input class="form-control" type="text" id="titulo" name="titulo" placeholder="Escribe el título de la nota" required>
                    </div>

                    <div class="form-group form-group-full">
                        <label for="contenido">Contenido</label>
                        <textarea class="form-control" id="contenido" name="contenido" rows="6" placeholder="Escribe aquí el contenido de la nota..." required></textarea>
                    </div>

                    <div class="form-group">
                        <label for="prioridad">Prioridad</label>
                        <select class="form-control" id="prioridad" name="prioridad" required>
                            <option value="BAJA">BAJA</option>
                            <option value="MEDIA">MEDIA</option>
                            <option value="ALTA">ALTA</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="estado">Estado</label>
                        <select class="form-control" id="estado" name="estado" required>
                            <option value="ACTIVA">ACTIVA</option>
                            <option value="ARCHIVADA">ARCHIVADA</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions" style="margin-top: 24px;">
                    <button type="submit" class="btn btn-primary">Guardar Nota</button>
                    <a href="${pageContext.request.contextPath}/notas?accion=listar" class="btn btn-cancel">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>