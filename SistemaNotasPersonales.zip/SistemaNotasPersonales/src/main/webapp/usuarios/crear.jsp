<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Nuevo Usuario | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/crear.css">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Registro de acceso</span>
                <h1 class="title-page">Crear Usuario</h1>
                <p class="subtitle-page">
                    Registra un nuevo usuario para que pueda administrar notas dentro del sistema.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/usuarios?accion=listar" class="btn btn-secondary">Volver al Listado</a>
            </div>
        </div>

        <div class="form-card">
            <div class="form-header">
                <h2>Información del usuario</h2>
                <p>Completa todos los campos necesarios para registrar un nuevo usuario.</p>
            </div>

            <form action="${pageContext.request.contextPath}/usuarios" method="post">
                <input type="hidden" name="accion" value="guardar">

                <div class="form-grid">
                    <div class="form-group">
                        <label for="nombre">Nombre</label>
                        <input class="form-control" type="text" id="nombre" name="nombre" placeholder="Ingresa el nombre" required>
                    </div>

                    <div class="form-group">
                        <label for="apellido">Apellido</label>
                        <input class="form-control" type="text" id="apellido" name="apellido" placeholder="Ingresa el apellido" required>
                    </div>

                    <div class="form-group">
                        <label for="correo">Correo</label>
                        <input class="form-control" type="email" id="correo" name="correo" placeholder="correo@ejemplo.com" required>
                    </div>

                    <div class="form-group">
                        <label for="clave">Clave</label>
                        <input class="form-control" type="text" id="clave" name="clave" placeholder="Ingresa la clave" required>
                    </div>

                    <div class="form-group">
                        <label for="telefono">Teléfono</label>
                        <input class="form-control" type="text" id="telefono" name="telefono" placeholder="Ej: 3001234567">
                    </div>

                    <div class="form-group">
                        <label for="documento">Documento</label>
                        <input class="form-control" type="text" id="documento" name="documento" placeholder="Número de documento">
                    </div>

                    <div class="form-group">
                        <label for="estado">Estado</label>
                        <select class="form-control" id="estado" name="estado" required>
                            <option value="ACTIVO">ACTIVO</option>
                            <option value="INACTIVO">INACTIVO</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions" style="margin-top: 24px;">
                    <button type="submit" class="btn btn-primary">Guardar Usuario</button>
                    <a href="${pageContext.request.contextPath}/usuarios?accion=listar" class="btn btn-cancel">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>