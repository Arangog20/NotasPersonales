<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.List"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Usuario"%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Usuarios | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/listar.css">
</head>
<body>
    <%
        String mensaje = request.getParameter("mensaje");
        String tipo = request.getParameter("tipo");
        List<Usuario> listaUsuarios = (List<Usuario>) request.getAttribute("listaUsuarios");
    %>

    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Gestión de usuarios</span>
                <h1 class="title-page">Usuarios</h1>
                <p class="subtitle-page">
                    Consulta, administra y actualiza los usuarios registrados en el sistema.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/usuarios/crear.jsp" class="btn btn-primary">Nuevo Usuario</a>
                <a href="${pageContext.request.contextPath}/index.html" class="btn btn-secondary">Volver al Inicio</a>
            </div>
        </div>

        <% if (mensaje != null && !mensaje.trim().isEmpty()) { %>
            <div class="alert <%= "success".equals(tipo) ? "alert-success" : "alert-error" %>">
                <%= mensaje %>
            </div>
        <% } %>

        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre Completo</th>
                        <th>Correo</th>
                        <th>Teléfono</th>
                        <th>Documento</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <% if (listaUsuarios != null && !listaUsuarios.isEmpty()) { 
                        for (Usuario u : listaUsuarios) { %>
                        <tr>
                            <td><%= u.getId() %></td>
                            <td><strong><%= u.getNombre() %> <%= u.getApellido() %></strong></td>
                            <td><%= u.getCorreo() %></td>
                            <td><%= u.getTelefono() != null ? u.getTelefono() : "-" %></td>
                            <td><%= u.getDocumento() != null ? u.getDocumento() : "-" %></td>
                            <td>
                                <span class="badge badge-<%= u.getEstado().toLowerCase() %>">
                                    <%= u.getEstado() %>
                                </span>
                            </td>
                            <td>
                                <div class="cell-actions">
                                    <a class="btn btn-edit" href="${pageContext.request.contextPath}/usuarios?accion=editar&id=<%= u.getId() %>">Editar</a>
                                    <a class="btn btn-delete" href="${pageContext.request.contextPath}/usuarios?accion=eliminar&id=<%= u.getId() %>"
                                       onclick="return confirm('¿Deseas eliminar este usuario?');">Eliminar</a>
                                </div>
                            </td>
                        </tr>
                    <%  }
                    } else { %>
                        <tr>
                            <td colspan="7" class="empty-table">No hay usuarios registrados.</td>
                        </tr>
                    <% } %>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>