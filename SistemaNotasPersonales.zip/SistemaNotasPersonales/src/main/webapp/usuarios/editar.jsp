<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="com.proyecto.sistemanotaspersonales.modelos.Usuario"%>
<%
    Usuario usuario = (Usuario) request.getAttribute("usuario");
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Editar Usuario | Sistema de Notas Personales</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/estilos.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/css/editar.css">
</head>
<body>
    <div class="container">
        <div class="topbar">
            <div class="topbar-left">
                <span class="label-page">Actualización de datos</span>
                <h1 class="title-page">Editar Usuario</h1>
                <p class="subtitle-page">
                    Modifica la información del usuario seleccionado y guarda los cambios realizados.
                </p>
            </div>

            <div class="topbar-actions">
                <a href="${pageContext.request.contextPath}/usuarios?accion=listar" class="btn btn-secondary">Volver al Listado</a>
            </div>
        </div>

        <div class="edit-card">
            <div class="edit-header">
                <h2>Información del usuario</h2>
                <p>Actualiza los campos necesarios del registro seleccionado.</p>
            </div>

            <form action="${pageContext.request.contextPath}/usuarios" method="post">
                <input type="hidden" name="accion" value="actualizar">
                <input type="hidden" name="id" value="<%= usuario.getId() %>">

                <div class="edit-grid">
                    <div class="edit-group">
                        <label for="nombre">Nombre</label>
                        <input class="edit-control" type="text" id="nombre" name="nombre" value="<%= usuario.getNombre() %>" required>
                    </div>

                    <div class="edit-group">
                        <label for="apellido">Apellido</label>
                        <input class="edit-control" type="text" id="apellido" name="apellido" value="<%= usuario.getApellido() %>" required>
                    </div>

                    <div class="edit-group">
                        <label for="correo">Correo</label>
                        <input class="edit-control" type="email" id="correo" name="correo" value="<%= usuario.getCorreo() %>" required>
                    </div>

                    <div class="edit-group">
                        <label for="clave">Clave</label>
                        <input class="edit-control" type="text" id="clave" name="clave" value="<%= usuario.getClave() %>" required>
                    </div>

                    <div class="edit-group">
                        <label for="telefono">Teléfono</label>
                        <input class="edit-control" type="text" id="telefono" name="telefono" value="<%= usuario.getTelefono() != null ? usuario.getTelefono() : "" %>">
                    </div>

                    <div class="edit-group">
                        <label for="documento">Documento</label>
                        <input class="edit-control" type="text" id="documento" name="documento" value="<%= usuario.getDocumento() != null ? usuario.getDocumento() : "" %>">
                    </div>

                    <div class="edit-group">
                        <label for="estado">Estado</label>
                        <select class="edit-control" id="estado" name="estado">
                            <option value="ACTIVO" <%= "ACTIVO".equals(usuario.getEstado()) ? "selected" : "" %>>ACTIVO</option>
                            <option value="INACTIVO" <%= "INACTIVO".equals(usuario.getEstado()) ? "selected" : "" %>>INACTIVO</option>
                        </select>
                    </div>
                </div>

                <div class="form-actions" style="margin-top: 24px;">
                    <button type="submit" class="btn btn-primary">Actualizar Usuario</button>
                    <a href="${pageContext.request.contextPath}/usuarios?accion=listar" class="btn btn-cancel">Cancelar</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>