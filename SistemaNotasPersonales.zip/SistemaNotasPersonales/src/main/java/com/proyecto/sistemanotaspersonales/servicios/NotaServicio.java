package com.proyecto.sistemanotaspersonales.servicios;

import com.proyecto.sistemanotaspersonales.dao.NotaDAO;
import com.proyecto.sistemanotaspersonales.modelos.Nota;
import com.proyecto.sistemanotaspersonales.utils.Validador;
import java.util.List;

public class NotaServicio {

    private final NotaDAO notaDAO = new NotaDAO();

    public boolean registrar(Nota nota) {
        if (nota == null) return false;
        if (nota.getUsuarioId() <= 0) return false;
        if (nota.getCategoriaId() <= 0) return false;
        if (Validador.esTextoVacio(nota.getTitulo())) return false;
        if (Validador.esTextoVacio(nota.getContenido())) return false;
        if (!Validador.esOpcionValida(nota.getPrioridad(), "BAJA", "MEDIA", "ALTA")) return false;
        if (!Validador.esOpcionValida(nota.getEstado(), "ACTIVA", "ARCHIVADA", "ELIMINADA")) return false;

        return notaDAO.insertar(nota);
    }

    public List<Nota> listarTodas() {
        return notaDAO.listarTodas();
    }

    public Nota buscarPorId(int id) {
        if (id <= 0) return null;
        return notaDAO.buscarPorId(id);
    }

    public List<Nota> listarPorUsuario(int usuarioId) {
        if (usuarioId <= 0) return List.of();
        return notaDAO.listarPorUsuario(usuarioId);
    }

    public List<Nota> listarPorCategoria(int categoriaId) {
        if (categoriaId <= 0) return List.of();
        return notaDAO.listarPorCategoria(categoriaId);
    }

    public boolean actualizar(Nota nota) {
        if (nota == null) return false;
        if (nota.getId() <= 0) return false;
        if (nota.getUsuarioId() <= 0) return false;
        if (nota.getCategoriaId() <= 0) return false;
        if (Validador.esTextoVacio(nota.getTitulo())) return false;
        if (Validador.esTextoVacio(nota.getContenido())) return false;
        if (!Validador.esOpcionValida(nota.getPrioridad(), "BAJA", "MEDIA", "ALTA")) return false;
        if (!Validador.esOpcionValida(nota.getEstado(), "ACTIVA", "ARCHIVADA", "ELIMINADA")) return false;

        return notaDAO.actualizar(nota);
    }

    public boolean eliminar(int id) {
        if (id <= 0) return false;
        return notaDAO.eliminar(id);
    }
}