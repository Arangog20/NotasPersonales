package com.proyecto.sistemanotaspersonales.utils;

import com.proyecto.sistemanotaspersonales.dao.ConexionBD;
import java.sql.Connection;

public class TestConexion {

    public static void main(String[] args) {
        try (Connection conn = ConexionBD.getConnection()) {
            System.out.println("Driver de MySQL cargado correctamente.");
            if (conn != null) {
                System.out.println("Conexion exitosa a la base de datos.");
            } else {
                System.out.println("No se pudo conectar a la base de datos.");
            }
        } catch (Exception e) {
            System.out.println("Error de conexion: " + e.getMessage());
            e.printStackTrace();
        }
    }
}