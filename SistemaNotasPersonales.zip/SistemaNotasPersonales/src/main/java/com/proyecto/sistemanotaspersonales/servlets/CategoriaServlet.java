package com.proyecto.sistemanotaspersonales.servlets;

import com.proyecto.sistemanotaspersonales.modelos.Categoria;
import com.proyecto.sistemanotaspersonales.servicios.CategoriaServicio;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/categorias")
public class CategoriaServlet extends HttpServlet {

    private final CategoriaServicio categoriaServicio = new CategoriaServicio();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        if (accion == null || accion.equals("listar")) {
            List<Categoria> listaCategorias = categoriaServicio.listarTodas();
            request.setAttribute("listaCategorias", listaCategorias);
            request.getRequestDispatcher("/categorias/listar.jsp").forward(request, response);

        } else if (accion.equals("editar")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Categoria categoria = categoriaServicio.buscarPorId(id);
            request.setAttribute("categoria", categoria);
            request.getRequestDispatcher("/categorias/editar.jsp").forward(request, response);

        } else if (accion.equals("eliminar")) {
            int id = Integer.parseInt(request.getParameter("id"));
            categoriaServicio.eliminar(id);
            response.sendRedirect("categorias?accion=listar");

        } else {
            response.sendRedirect("categorias?accion=listar");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        String nombre = request.getParameter("nombre");
        String descripcion = request.getParameter("descripcion");
        String color = request.getParameter("color");
        String estado = request.getParameter("estado");

        if ("guardar".equals(accion)) {
            Categoria categoria = new Categoria();
            categoria.setNombre(nombre);
            categoria.setDescripcion(descripcion);
            categoria.setColor(color);
            categoria.setEstado(estado);

            categoriaServicio.registrar(categoria);

        } else if ("actualizar".equals(accion)) {
            int id = Integer.parseInt(request.getParameter("id"));

            Categoria categoria = new Categoria();
            categoria.setId(id);
            categoria.setNombre(nombre);
            categoria.setDescripcion(descripcion);
            categoria.setColor(color);
            categoria.setEstado(estado);

            categoriaServicio.actualizar(categoria);
        }

        response.sendRedirect("categorias?accion=listar");
    }
}