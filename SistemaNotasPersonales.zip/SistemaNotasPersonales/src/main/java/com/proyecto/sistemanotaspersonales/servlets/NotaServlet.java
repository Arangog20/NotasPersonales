package com.proyecto.sistemanotaspersonales.servlets;

import com.proyecto.sistemanotaspersonales.modelos.Categoria;
import com.proyecto.sistemanotaspersonales.modelos.Nota;
import com.proyecto.sistemanotaspersonales.modelos.Usuario;
import com.proyecto.sistemanotaspersonales.servicios.CategoriaServicio;
import com.proyecto.sistemanotaspersonales.servicios.NotaServicio;
import com.proyecto.sistemanotaspersonales.servicios.UsuarioServicio;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/notas")
public class NotaServlet extends HttpServlet {

    private final NotaServicio notaServicio = new NotaServicio();
    private final UsuarioServicio usuarioServicio = new UsuarioServicio();
    private final CategoriaServicio categoriaServicio = new CategoriaServicio();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        if (accion == null || accion.equals("listar")) {
            List<Nota> listaNotas = notaServicio.listarTodas();
            request.setAttribute("listaNotas", listaNotas);
            request.getRequestDispatcher("/notas/listar.jsp").forward(request, response);

        } else if (accion.equals("nuevo")) {
            List<Usuario> listaUsuarios = usuarioServicio.listarTodos();
            List<Categoria> listaCategorias = categoriaServicio.listarTodas();
            request.setAttribute("listaUsuarios", listaUsuarios);
            request.setAttribute("listaCategorias", listaCategorias);
            request.getRequestDispatcher("/notas/crear.jsp").forward(request, response);

        } else if (accion.equals("editar")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Nota nota = notaServicio.buscarPorId(id);
            List<Usuario> listaUsuarios = usuarioServicio.listarTodos();
            List<Categoria> listaCategorias = categoriaServicio.listarTodas();

            request.setAttribute("nota", nota);
            request.setAttribute("listaUsuarios", listaUsuarios);
            request.setAttribute("listaCategorias", listaCategorias);
            request.getRequestDispatcher("/notas/editar.jsp").forward(request, response);

        } else if (accion.equals("eliminar")) {
            int id = Integer.parseInt(request.getParameter("id"));
            notaServicio.eliminar(id);
            response.sendRedirect("notas?accion=listar");

        } else {
            response.sendRedirect("notas?accion=listar");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        int usuarioId = Integer.parseInt(request.getParameter("usuarioId"));
        int categoriaId = Integer.parseInt(request.getParameter("categoriaId"));
        String titulo = request.getParameter("titulo");
        String contenido = request.getParameter("contenido");
        String prioridad = request.getParameter("prioridad");
        String estado = request.getParameter("estado");

        if ("guardar".equals(accion)) {
            Nota nota = new Nota();
            nota.setUsuarioId(usuarioId);
            nota.setCategoriaId(categoriaId);
            nota.setTitulo(titulo);
            nota.setContenido(contenido);
            nota.setPrioridad(prioridad);
            nota.setEstado(estado);

            notaServicio.registrar(nota);

        } else if ("actualizar".equals(accion)) {
            int id = Integer.parseInt(request.getParameter("id"));

            Nota nota = new Nota();
            nota.setId(id);
            nota.setUsuarioId(usuarioId);
            nota.setCategoriaId(categoriaId);
            nota.setTitulo(titulo);
            nota.setContenido(contenido);
            nota.setPrioridad(prioridad);
            nota.setEstado(estado);

            notaServicio.actualizar(nota);
        }

        response.sendRedirect("notas?accion=listar");
    }
}