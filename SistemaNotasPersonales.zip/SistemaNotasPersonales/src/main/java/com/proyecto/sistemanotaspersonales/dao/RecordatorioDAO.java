package com.proyecto.sistemanotaspersonales.dao;

import com.proyecto.sistemanotaspersonales.modelos.Recordatorio;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RecordatorioDAO {

    public boolean insertar(Recordatorio recordatorio) {
        String sql = "INSERT INTO recordatorios (nota_id, fecha_recordatorio, mensaje, estado) VALUES (?, ?, ?, ?)";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, recordatorio.getNotaId());
            ps.setTimestamp(2, Timestamp.valueOf(recordatorio.getFechaRecordatorio()));
            ps.setString(3, recordatorio.getMensaje());
            ps.setString(4, recordatorio.getEstado());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error al insertar recordatorio: " + e.getMessage());
            return false;
        }
    }

    public List<Recordatorio> listarTodos() {
        List<Recordatorio> lista = new ArrayList<>();
        String sql = "SELECT * FROM recordatorios";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Recordatorio recordatorio = new Recordatorio();
                recordatorio.setId(rs.getInt("id"));
                recordatorio.setNotaId(rs.getInt("nota_id"));

                Timestamp fecha = rs.getTimestamp("fecha_recordatorio");
                if (fecha != null) {
                    recordatorio.setFechaRecordatorio(fecha.toLocalDateTime());
                }

                recordatorio.setMensaje(rs.getString("mensaje"));
                recordatorio.setEstado(rs.getString("estado"));

                lista.add(recordatorio);
            }

        } catch (SQLException e) {
            System.out.println("Error al listar recordatorios: " + e.getMessage());
        }

        return lista;
    }

    public Recordatorio buscarPorId(int id) {
        String sql = "SELECT * FROM recordatorios WHERE id = ?";
        Recordatorio recordatorio = null;

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    recordatorio = new Recordatorio();
                    recordatorio.setId(rs.getInt("id"));
                    recordatorio.setNotaId(rs.getInt("nota_id"));

                    Timestamp fecha = rs.getTimestamp("fecha_recordatorio");
                    if (fecha != null) {
                        recordatorio.setFechaRecordatorio(fecha.toLocalDateTime());
                    }

                    recordatorio.setMensaje(rs.getString("mensaje"));
                    recordatorio.setEstado(rs.getString("estado"));
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al buscar recordatorio por ID: " + e.getMessage());
        }

        return recordatorio;
    }

    public List<Recordatorio> listarPorNota(int notaId) {
        List<Recordatorio> lista = new ArrayList<>();
        String sql = "SELECT * FROM recordatorios WHERE nota_id = ?";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, notaId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Recordatorio recordatorio = new Recordatorio();
                    recordatorio.setId(rs.getInt("id"));
                    recordatorio.setNotaId(rs.getInt("nota_id"));

                    Timestamp fecha = rs.getTimestamp("fecha_recordatorio");
                    if (fecha != null) {
                        recordatorio.setFechaRecordatorio(fecha.toLocalDateTime());
                    }

                    recordatorio.setMensaje(rs.getString("mensaje"));
                    recordatorio.setEstado(rs.getString("estado"));

                    lista.add(recordatorio);
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al listar recordatorios por nota: " + e.getMessage());
        }

        return lista;
    }

    public boolean actualizar(Recordatorio recordatorio) {
        String sql = "UPDATE recordatorios SET nota_id = ?, fecha_recordatorio = ?, mensaje = ?, estado = ? WHERE id = ?";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, recordatorio.getNotaId());
            ps.setTimestamp(2, Timestamp.valueOf(recordatorio.getFechaRecordatorio()));
            ps.setString(3, recordatorio.getMensaje());
            ps.setString(4, recordatorio.getEstado());
            ps.setInt(5, recordatorio.getId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error al actualizar recordatorio: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM recordatorios WHERE id = ?";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error al eliminar recordatorio: " + e.getMessage());
            return false;
        }
    }
}