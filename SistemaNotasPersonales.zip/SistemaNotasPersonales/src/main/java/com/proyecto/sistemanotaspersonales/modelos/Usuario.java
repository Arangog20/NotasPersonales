package com.proyecto.sistemanotaspersonales.modelos;

import java.time.LocalDateTime;

public class Usuario extends Persona {

    private String clave;
    private LocalDateTime fechaRegistro;
    private String estado;

    public Usuario() {
    }

    public Usuario(String clave, LocalDateTime fechaRegistro, String estado) {
        this.clave = clave;
        this.fechaRegistro = fechaRegistro;
        this.estado = estado;
    }

    public Usuario(int id, String nombre, String apellido, String correo, String telefono, String documento,
                   String clave, LocalDateTime fechaRegistro, String estado) {
        super(id, nombre, apellido, correo, telefono, documento);
        this.clave = clave;
        this.fechaRegistro = fechaRegistro;
        this.estado = estado;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public LocalDateTime getFechaRegistro() {
        return fechaRegistro;
    }

    public void setFechaRegistro(LocalDateTime fechaRegistro) {
        this.fechaRegistro = fechaRegistro;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", correo='" + correo + '\'' +
                ", telefono='" + telefono + '\'' +
                ", documento='" + documento + '\'' +
                ", clave='" + clave + '\'' +
                ", fechaRegistro=" + fechaRegistro +
                ", estado='" + estado + '\'' +
                '}';
    }
}