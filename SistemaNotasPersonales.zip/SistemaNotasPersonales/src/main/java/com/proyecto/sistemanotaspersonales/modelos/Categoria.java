package com.proyecto.sistemanotaspersonales.modelos;

public class Categoria {

    private int id;
    private String nombre;
    private String descripcion;
    private String color;
    private String estado;

    public Categoria() {
    }

    public Categoria(int id, String nombre, String descripcion, String color, String estado) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.color = color;
        this.estado = estado;
    }

    public Categoria(String nombre, String descripcion, String color, String estado) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.color = color;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Categoria{" +
                "id=" + id +
                ", nombre='" + nombre + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", color='" + color + '\'' +
                ", estado='" + estado + '\'' +
                '}';
    }
}