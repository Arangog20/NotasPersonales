package com.proyecto.sistemanotaspersonales.servicios;

import com.proyecto.sistemanotaspersonales.dao.RecordatorioDAO;
import com.proyecto.sistemanotaspersonales.modelos.Recordatorio;
import com.proyecto.sistemanotaspersonales.utils.Validador;
import java.util.List;

public class RecordatorioServicio {

    private final RecordatorioDAO recordatorioDAO = new RecordatorioDAO();

    public boolean registrar(Recordatorio recordatorio) {
        if (recordatorio == null) return false;
        if (recordatorio.getNotaId() <= 0) return false;
        if (recordatorio.getFechaRecordatorio() == null) return false;
        if (Validador.esTextoVacio(recordatorio.getMensaje())) return false;
        if (!Validador.esOpcionValida(recordatorio.getEstado(), "PENDIENTE", "ENVIADO", "CANCELADO")) return false;

        return recordatorioDAO.insertar(recordatorio);
    }

    public List<Recordatorio> listarTodos() {
        return recordatorioDAO.listarTodos();
    }

    public Recordatorio buscarPorId(int id) {
        if (id <= 0) return null;
        return recordatorioDAO.buscarPorId(id);
    }

    public List<Recordatorio> listarPorNota(int notaId) {
        if (notaId <= 0) return List.of();
        return recordatorioDAO.listarPorNota(notaId);
    }

    public boolean actualizar(Recordatorio recordatorio) {
        if (recordatorio == null) return false;
        if (recordatorio.getId() <= 0) return false;
        if (recordatorio.getNotaId() <= 0) return false;
        if (recordatorio.getFechaRecordatorio() == null) return false;
        if (Validador.esTextoVacio(recordatorio.getMensaje())) return false;
        if (!Validador.esOpcionValida(recordatorio.getEstado(), "PENDIENTE", "ENVIADO", "CANCELADO")) return false;

        return recordatorioDAO.actualizar(recordatorio);
    }

    public boolean eliminar(int id) {
        if (id <= 0) return false;
        return recordatorioDAO.eliminar(id);
    }
}