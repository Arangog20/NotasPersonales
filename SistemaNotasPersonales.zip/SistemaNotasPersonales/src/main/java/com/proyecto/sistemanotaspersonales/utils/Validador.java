package com.proyecto.sistemanotaspersonales.utils;

public class Validador {

    public static boolean esTextoVacio(String texto) {
        return texto == null || texto.trim().isEmpty();
    }

    public static boolean esCorreoValido(String correo) {
        if (esTextoVacio(correo)) {
            return false;
        }
        return correo.matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    }

    public static boolean esNumeroEntero(String texto) {
        if (esTextoVacio(texto)) {
            return false;
        }
        try {
            Integer.parseInt(texto);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean esNumeroDecimal(String texto) {
        if (esTextoVacio(texto)) {
            return false;
        }
        try {
            Double.parseDouble(texto);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static boolean longitudMinima(String texto, int longitud) {
        return texto != null && texto.trim().length() >= longitud;
    }

    public static boolean longitudMaxima(String texto, int longitud) {
        return texto != null && texto.trim().length() <= longitud;
    }

    public static boolean rangoEntero(int valor, int minimo, int maximo) {
        return valor >= minimo && valor <= maximo;
    }

    public static boolean esOpcionValida(String valor, String... opciones) {
        if (valor == null) {
            return false;
        }

        for (String opcion : opciones) {
            if (valor.equalsIgnoreCase(opcion)) {
                return true;
            }
        }
        return false;
    }
}