package com.proyecto.sistemanotaspersonales.servicios;

import com.proyecto.sistemanotaspersonales.dao.CategoriaDAO;
import com.proyecto.sistemanotaspersonales.modelos.Categoria;
import com.proyecto.sistemanotaspersonales.utils.Validador;
import java.util.List;

public class CategoriaServicio {

    private final CategoriaDAO categoriaDAO = new CategoriaDAO();

    public boolean registrar(Categoria categoria) {
        if (categoria == null) return false;
        if (Validador.esTextoVacio(categoria.getNombre())) return false;
        if (Validador.esTextoVacio(categoria.getEstado())) return false;

        return categoriaDAO.insertar(categoria);
    }

    public List<Categoria> listarTodas() {
        return categoriaDAO.listarTodas();
    }

    public Categoria buscarPorId(int id) {
        if (id <= 0) return null;
        return categoriaDAO.buscarPorId(id);
    }

    public boolean actualizar(Categoria categoria) {
        if (categoria == null) return false;
        if (categoria.getId() <= 0) return false;
        if (Validador.esTextoVacio(categoria.getNombre())) return false;
        if (Validador.esTextoVacio(categoria.getEstado())) return false;

        return categoriaDAO.actualizar(categoria);
    }

    public boolean eliminar(int id) {
        if (id <= 0) return false;
        return categoriaDAO.eliminar(id);
    }
}