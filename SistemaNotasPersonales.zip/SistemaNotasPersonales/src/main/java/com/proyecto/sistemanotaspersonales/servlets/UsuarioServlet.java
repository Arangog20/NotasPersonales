package com.proyecto.sistemanotaspersonales.servlets;

import com.proyecto.sistemanotaspersonales.modelos.Usuario;
import com.proyecto.sistemanotaspersonales.servicios.UsuarioServicio;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

@WebServlet("/usuarios")
public class UsuarioServlet extends HttpServlet {

    private final UsuarioServicio usuarioServicio = new UsuarioServicio();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        if (accion == null || accion.equals("listar")) {
            List<Usuario> listaUsuarios = usuarioServicio.listarTodos();
            request.setAttribute("listaUsuarios", listaUsuarios);
            request.getRequestDispatcher("/usuarios/listar.jsp").forward(request, response);

        } else if (accion.equals("editar")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Usuario usuario = usuarioServicio.buscarPorId(id);
            request.setAttribute("usuario", usuario);
            request.getRequestDispatcher("/usuarios/editar.jsp").forward(request, response);

        } else if (accion.equals("eliminar")) {
            int id = Integer.parseInt(request.getParameter("id"));
            usuarioServicio.eliminar(id);
            response.sendRedirect("usuarios?accion=listar");

        } else {
            response.sendRedirect("usuarios?accion=listar");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        String nombre = request.getParameter("nombre");
        String apellido = request.getParameter("apellido");
        String correo = request.getParameter("correo");
        String clave = request.getParameter("clave");
        String telefono = request.getParameter("telefono");
        String documento = request.getParameter("documento");
        String estado = request.getParameter("estado");

        if ("guardar".equals(accion)) {
            Usuario usuario = new Usuario();
            usuario.setNombre(nombre);
            usuario.setApellido(apellido);
            usuario.setCorreo(correo);
            usuario.setClave(clave);
            usuario.setTelefono(telefono);
            usuario.setDocumento(documento);
            usuario.setEstado(estado);
            usuario.setFechaRegistro(LocalDateTime.now());

            usuarioServicio.registrar(usuario);

        } else if ("actualizar".equals(accion)) {
            int id = Integer.parseInt(request.getParameter("id"));

            Usuario usuario = new Usuario();
            usuario.setId(id);
            usuario.setNombre(nombre);
            usuario.setApellido(apellido);
            usuario.setCorreo(correo);
            usuario.setClave(clave);
            usuario.setTelefono(telefono);
            usuario.setDocumento(documento);
            usuario.setEstado(estado);

            usuarioServicio.actualizar(usuario);
        }

        response.sendRedirect("usuarios?accion=listar");
    }
}