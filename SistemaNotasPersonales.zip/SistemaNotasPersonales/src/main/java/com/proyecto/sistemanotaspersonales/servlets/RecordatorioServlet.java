package com.proyecto.sistemanotaspersonales.servlets;

import com.proyecto.sistemanotaspersonales.modelos.Nota;
import com.proyecto.sistemanotaspersonales.modelos.Recordatorio;
import com.proyecto.sistemanotaspersonales.servicios.NotaServicio;
import com.proyecto.sistemanotaspersonales.servicios.RecordatorioServicio;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

@WebServlet("/recordatorios")
public class RecordatorioServlet extends HttpServlet {

    private final RecordatorioServicio recordatorioServicio = new RecordatorioServicio();
    private final NotaServicio notaServicio = new NotaServicio();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        if (accion == null || accion.equals("listar")) {
            List<Recordatorio> listaRecordatorios = recordatorioServicio.listarTodos();
            request.setAttribute("listaRecordatorios", listaRecordatorios);
            request.getRequestDispatcher("/recordatorios/listar.jsp").forward(request, response);

        } else if (accion.equals("nuevo")) {
            List<Nota> listaNotas = notaServicio.listarTodas();
            request.setAttribute("listaNotas", listaNotas);
            request.getRequestDispatcher("/recordatorios/crear.jsp").forward(request, response);

        } else if (accion.equals("editar")) {
            int id = Integer.parseInt(request.getParameter("id"));
            Recordatorio recordatorio = recordatorioServicio.buscarPorId(id);
            List<Nota> listaNotas = notaServicio.listarTodas();

            request.setAttribute("recordatorio", recordatorio);
            request.setAttribute("listaNotas", listaNotas);
            request.getRequestDispatcher("/recordatorios/editar.jsp").forward(request, response);

        } else if (accion.equals("eliminar")) {
            int id = Integer.parseInt(request.getParameter("id"));
            recordatorioServicio.eliminar(id);
            response.sendRedirect("recordatorios?accion=listar");

        } else {
            response.sendRedirect("recordatorios?accion=listar");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        int notaId = Integer.parseInt(request.getParameter("notaId"));
        String fechaTexto = request.getParameter("fechaRecordatorio");
        String mensaje = request.getParameter("mensaje");
        String estado = request.getParameter("estado");

        LocalDateTime fechaRecordatorio = LocalDateTime.parse(fechaTexto);

        if ("guardar".equals(accion)) {
            Recordatorio recordatorio = new Recordatorio();
            recordatorio.setNotaId(notaId);
            recordatorio.setFechaRecordatorio(fechaRecordatorio);
            recordatorio.setMensaje(mensaje);
            recordatorio.setEstado(estado);

            recordatorioServicio.registrar(recordatorio);

        } else if ("actualizar".equals(accion)) {
            int id = Integer.parseInt(request.getParameter("id"));

            Recordatorio recordatorio = new Recordatorio();
            recordatorio.setId(id);
            recordatorio.setNotaId(notaId);
            recordatorio.setFechaRecordatorio(fechaRecordatorio);
            recordatorio.setMensaje(mensaje);
            recordatorio.setEstado(estado);

            recordatorioServicio.actualizar(recordatorio);
        }

        response.sendRedirect("recordatorios?accion=listar");
    }
}