package com.proyecto.sistemanotaspersonales.modelos;

import java.time.LocalDateTime;

public class HistorialNota {

    private int id;
    private int notaId;
    private String accion;
    private String descripcion;
    private LocalDateTime fechaAccion;

    public HistorialNota() {
    }

    public HistorialNota(int id, int notaId, String accion, String descripcion, LocalDateTime fechaAccion) {
        this.id = id;
        this.notaId = notaId;
        this.accion = accion;
        this.descripcion = descripcion;
        this.fechaAccion = fechaAccion;
    }

    public HistorialNota(int notaId, String accion, String descripcion, LocalDateTime fechaAccion) {
        this.notaId = notaId;
        this.accion = accion;
        this.descripcion = descripcion;
        this.fechaAccion = fechaAccion;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNotaId() {
        return notaId;
    }

    public void setNotaId(int notaId) {
        this.notaId = notaId;
    }

    public String getAccion() {
        return accion;
    }

    public void setAccion(String accion) {
        this.accion = accion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public LocalDateTime getFechaAccion() {
        return fechaAccion;
    }

    public void setFechaAccion(LocalDateTime fechaAccion) {
        this.fechaAccion = fechaAccion;
    }

    @Override
    public String toString() {
        return "HistorialNota{" +
                "id=" + id +
                ", notaId=" + notaId +
                ", accion='" + accion + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", fechaAccion=" + fechaAccion +
                '}';
    }
}