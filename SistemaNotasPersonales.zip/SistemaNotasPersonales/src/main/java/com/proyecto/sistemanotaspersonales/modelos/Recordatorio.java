package com.proyecto.sistemanotaspersonales.modelos;

import java.time.LocalDateTime;

public class Recordatorio {

    private int id;
    private int notaId;
    private LocalDateTime fechaRecordatorio;
    private String mensaje;
    private String estado;

    public Recordatorio() {
    }

    public Recordatorio(int id, int notaId, LocalDateTime fechaRecordatorio, String mensaje, String estado) {
        this.id = id;
        this.notaId = notaId;
        this.fechaRecordatorio = fechaRecordatorio;
        this.mensaje = mensaje;
        this.estado = estado;
    }

    public Recordatorio(int notaId, LocalDateTime fechaRecordatorio, String mensaje, String estado) {
        this.notaId = notaId;
        this.fechaRecordatorio = fechaRecordatorio;
        this.mensaje = mensaje;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNotaId() {
        return notaId;
    }

    public void setNotaId(int notaId) {
        this.notaId = notaId;
    }

    public LocalDateTime getFechaRecordatorio() {
        return fechaRecordatorio;
    }

    public void setFechaRecordatorio(LocalDateTime fechaRecordatorio) {
        this.fechaRecordatorio = fechaRecordatorio;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "Recordatorio{" +
                "id=" + id +
                ", notaId=" + notaId +
                ", fechaRecordatorio=" + fechaRecordatorio +
                ", mensaje='" + mensaje + '\'' +
                ", estado='" + estado + '\'' +
                '}';
    }
}