package com.proyecto.sistemanotaspersonales.dao;

import com.proyecto.sistemanotaspersonales.modelos.Nota;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NotaDAO {

    public boolean insertar(Nota nota) {
        String sql = "INSERT INTO notas (usuario_id, categoria_id, titulo, contenido, prioridad, estado) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, nota.getUsuarioId());
            ps.setInt(2, nota.getCategoriaId());
            ps.setString(3, nota.getTitulo());
            ps.setString(4, nota.getContenido());
            ps.setString(5, nota.getPrioridad());
            ps.setString(6, nota.getEstado());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error al insertar nota: " + e.getMessage());
            return false;
        }
    }

    public List<Nota> listarTodas() {
        List<Nota> lista = new ArrayList<>();
        String sql = "SELECT * FROM notas";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Nota nota = new Nota();
                nota.setId(rs.getInt("id"));
                nota.setUsuarioId(rs.getInt("usuario_id"));
                nota.setCategoriaId(rs.getInt("categoria_id"));
                nota.setTitulo(rs.getString("titulo"));
                nota.setContenido(rs.getString("contenido"));
                nota.setPrioridad(rs.getString("prioridad"));
                nota.setEstado(rs.getString("estado"));

                Timestamp fechaCreacion = rs.getTimestamp("fecha_creacion");
                if (fechaCreacion != null) {
                    nota.setFechaCreacion(fechaCreacion.toLocalDateTime());
                }

                Timestamp fechaActualizacion = rs.getTimestamp("fecha_actualizacion");
                if (fechaActualizacion != null) {
                    nota.setFechaActualizacion(fechaActualizacion.toLocalDateTime());
                }

                lista.add(nota);
            }

        } catch (SQLException e) {
            System.out.println("Error al listar notas: " + e.getMessage());
        }

        return lista;
    }

    public Nota buscarPorId(int id) {
        String sql = "SELECT * FROM notas WHERE id = ?";
        Nota nota = null;

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    nota = new Nota();
                    nota.setId(rs.getInt("id"));
                    nota.setUsuarioId(rs.getInt("usuario_id"));
                    nota.setCategoriaId(rs.getInt("categoria_id"));
                    nota.setTitulo(rs.getString("titulo"));
                    nota.setContenido(rs.getString("contenido"));
                    nota.setPrioridad(rs.getString("prioridad"));
                    nota.setEstado(rs.getString("estado"));

                    Timestamp fechaCreacion = rs.getTimestamp("fecha_creacion");
                    if (fechaCreacion != null) {
                        nota.setFechaCreacion(fechaCreacion.toLocalDateTime());
                    }

                    Timestamp fechaActualizacion = rs.getTimestamp("fecha_actualizacion");
                    if (fechaActualizacion != null) {
                        nota.setFechaActualizacion(fechaActualizacion.toLocalDateTime());
                    }
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al buscar nota por ID: " + e.getMessage());
        }

        return nota;
    }

    public List<Nota> listarPorUsuario(int usuarioId) {
        List<Nota> lista = new ArrayList<>();
        String sql = "SELECT * FROM notas WHERE usuario_id = ?";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, usuarioId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Nota nota = new Nota();
                    nota.setId(rs.getInt("id"));
                    nota.setUsuarioId(rs.getInt("usuario_id"));
                    nota.setCategoriaId(rs.getInt("categoria_id"));
                    nota.setTitulo(rs.getString("titulo"));
                    nota.setContenido(rs.getString("contenido"));
                    nota.setPrioridad(rs.getString("prioridad"));
                    nota.setEstado(rs.getString("estado"));

                    Timestamp fechaCreacion = rs.getTimestamp("fecha_creacion");
                    if (fechaCreacion != null) {
                        nota.setFechaCreacion(fechaCreacion.toLocalDateTime());
                    }

                    Timestamp fechaActualizacion = rs.getTimestamp("fecha_actualizacion");
                    if (fechaActualizacion != null) {
                        nota.setFechaActualizacion(fechaActualizacion.toLocalDateTime());
                    }

                    lista.add(nota);
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al listar notas por usuario: " + e.getMessage());
        }

        return lista;
    }

    public List<Nota> listarPorCategoria(int categoriaId) {
        List<Nota> lista = new ArrayList<>();
        String sql = "SELECT * FROM notas WHERE categoria_id = ?";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, categoriaId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Nota nota = new Nota();
                    nota.setId(rs.getInt("id"));
                    nota.setUsuarioId(rs.getInt("usuario_id"));
                    nota.setCategoriaId(rs.getInt("categoria_id"));
                    nota.setTitulo(rs.getString("titulo"));
                    nota.setContenido(rs.getString("contenido"));
                    nota.setPrioridad(rs.getString("prioridad"));
                    nota.setEstado(rs.getString("estado"));

                    Timestamp fechaCreacion = rs.getTimestamp("fecha_creacion");
                    if (fechaCreacion != null) {
                        nota.setFechaCreacion(fechaCreacion.toLocalDateTime());
                    }

                    Timestamp fechaActualizacion = rs.getTimestamp("fecha_actualizacion");
                    if (fechaActualizacion != null) {
                        nota.setFechaActualizacion(fechaActualizacion.toLocalDateTime());
                    }

                    lista.add(nota);
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al listar notas por categoría: " + e.getMessage());
        }

        return lista;
    }

    public boolean actualizar(Nota nota) {
        String sql = "UPDATE notas SET usuario_id = ?, categoria_id = ?, titulo = ?, contenido = ?, prioridad = ?, estado = ? WHERE id = ?";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, nota.getUsuarioId());
            ps.setInt(2, nota.getCategoriaId());
            ps.setString(3, nota.getTitulo());
            ps.setString(4, nota.getContenido());
            ps.setString(5, nota.getPrioridad());
            ps.setString(6, nota.getEstado());
            ps.setInt(7, nota.getId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error al actualizar nota: " + e.getMessage());
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM notas WHERE id = ?";

        try (Connection conn = ConexionBD.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error al eliminar nota: " + e.getMessage());
            return false;
        }
    }
}