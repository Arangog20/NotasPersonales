package com.proyecto.sistemanotaspersonales.servicios;

import com.proyecto.sistemanotaspersonales.dao.UsuarioDAO;
import com.proyecto.sistemanotaspersonales.modelos.Usuario;
import com.proyecto.sistemanotaspersonales.utils.Validador;
import java.util.List;

public class UsuarioServicio {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    public boolean registrar(Usuario usuario) {
        if (usuario == null) return false;
        if (Validador.esTextoVacio(usuario.getNombre())) return false;
        if (Validador.esTextoVacio(usuario.getApellido())) return false;
        if (!Validador.esCorreoValido(usuario.getCorreo())) return false;
        if (Validador.esTextoVacio(usuario.getClave())) return false;
        if (Validador.esTextoVacio(usuario.getEstado())) return false;

        return usuarioDAO.insertar(usuario);
    }

    public List<Usuario> listarTodos() {
        return usuarioDAO.listarTodos();
    }

    public Usuario buscarPorId(int id) {
        if (id <= 0) return null;
        return usuarioDAO.buscarPorId(id);
    }

    public boolean actualizar(Usuario usuario) {
        if (usuario == null) return false;
        if (usuario.getId() <= 0) return false;
        if (Validador.esTextoVacio(usuario.getNombre())) return false;
        if (Validador.esTextoVacio(usuario.getApellido())) return false;
        if (!Validador.esCorreoValido(usuario.getCorreo())) return false;
        if (Validador.esTextoVacio(usuario.getClave())) return false;
        if (Validador.esTextoVacio(usuario.getEstado())) return false;

        return usuarioDAO.actualizar(usuario);
    }

    public boolean eliminar(int id) {
        if (id <= 0) return false;
        return usuarioDAO.eliminar(id);
    }
}