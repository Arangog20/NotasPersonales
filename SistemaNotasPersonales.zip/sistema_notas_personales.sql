-- =========================================================
-- PROYECTO: SISTEMA DE NOTAS PERSONALES
-- Base de datos completa y corregida para MySQL
-- Tecnologías objetivo: Java + HTML + Apache Tomcat + JDBC
-- =========================================================

-- =========================================================
-- 1. ELIMINAR Y CREAR BASE DE DATOS
-- =========================================================
DROP DATABASE IF EXISTS sistema_notas_personales;

CREATE DATABASE sistema_notas_personales
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE sistema_notas_personales;

-- =========================================================
-- 2. TABLA: usuarios
-- =========================================================
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    correo VARCHAR(150) NOT NULL UNIQUE,
    clave VARCHAR(255) NOT NULL,
    telefono VARCHAR(20),
    documento VARCHAR(30) UNIQUE,
    fecha_registro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    estado ENUM('ACTIVO', 'INACTIVO') NOT NULL DEFAULT 'ACTIVO',
    CONSTRAINT chk_usuario_nombre CHECK (CHAR_LENGTH(TRIM(nombre)) > 0),
    CONSTRAINT chk_usuario_apellido CHECK (CHAR_LENGTH(TRIM(apellido)) > 0),
    CONSTRAINT chk_usuario_correo CHECK (CHAR_LENGTH(TRIM(correo)) > 0),
    CONSTRAINT chk_usuario_clave CHECK (CHAR_LENGTH(TRIM(clave)) > 0)
);

-- =========================================================
-- 3. TABLA: categorias
-- =========================================================
CREATE TABLE categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    descripcion VARCHAR(255),
    color VARCHAR(20) DEFAULT '#3498db',
    estado ENUM('ACTIVA', 'INACTIVA') NOT NULL DEFAULT 'ACTIVA',
    CONSTRAINT chk_categoria_nombre CHECK (CHAR_LENGTH(TRIM(nombre)) > 0)
);

-- =========================================================
-- 4. TABLA: notas
-- =========================================================
CREATE TABLE notas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    categoria_id INT NOT NULL,
    titulo VARCHAR(150) NOT NULL,
    contenido TEXT NOT NULL,
    prioridad ENUM('BAJA', 'MEDIA', 'ALTA') NOT NULL DEFAULT 'MEDIA',
    estado ENUM('ACTIVA', 'ARCHIVADA', 'ELIMINADA') NOT NULL DEFAULT 'ACTIVA',
    fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fecha_actualizacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    CONSTRAINT fk_notas_usuario
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT fk_notas_categoria
        FOREIGN KEY (categoria_id) REFERENCES categorias(id)
        ON UPDATE CASCADE
        ON DELETE RESTRICT,

    CONSTRAINT chk_nota_titulo CHECK (CHAR_LENGTH(TRIM(titulo)) > 0),
    CONSTRAINT chk_nota_contenido CHECK (CHAR_LENGTH(TRIM(contenido)) > 0)
);

-- =========================================================
-- 5. TABLA: etiquetas
-- =========================================================
CREATE TABLE etiquetas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL UNIQUE,
    color VARCHAR(20) DEFAULT '#95a5a6',
    CONSTRAINT chk_etiqueta_nombre CHECK (CHAR_LENGTH(TRIM(nombre)) > 0)
);

-- =========================================================
-- 6. TABLA: nota_etiqueta
-- Relación muchos a muchos entre notas y etiquetas
-- =========================================================
CREATE TABLE nota_etiqueta (
    nota_id INT NOT NULL,
    etiqueta_id INT NOT NULL,
    PRIMARY KEY (nota_id, etiqueta_id),

    CONSTRAINT fk_nota_etiqueta_nota
        FOREIGN KEY (nota_id) REFERENCES notas(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT fk_nota_etiqueta_etiqueta
        FOREIGN KEY (etiqueta_id) REFERENCES etiquetas(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE
);

-- =========================================================
-- 7. TABLA: recordatorios
-- =========================================================
CREATE TABLE recordatorios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nota_id INT NOT NULL,
    fecha_recordatorio DATETIME NOT NULL,
    mensaje VARCHAR(255) NOT NULL,
    estado ENUM('PENDIENTE', 'ENVIADO', 'CANCELADO') NOT NULL DEFAULT 'PENDIENTE',

    CONSTRAINT fk_recordatorios_nota
        FOREIGN KEY (nota_id) REFERENCES notas(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT chk_recordatorio_mensaje CHECK (CHAR_LENGTH(TRIM(mensaje)) > 0)
);

-- =========================================================
-- 8. TABLA: historial_notas
-- =========================================================
CREATE TABLE historial_notas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nota_id INT NOT NULL,
    accion ENUM('CREACION', 'EDICION', 'ELIMINACION', 'ARCHIVADO', 'RESTAURACION') NOT NULL,
    descripcion VARCHAR(255) NOT NULL,
    fecha_accion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT fk_historial_nota
        FOREIGN KEY (nota_id) REFERENCES notas(id)
        ON UPDATE CASCADE
        ON DELETE CASCADE,

    CONSTRAINT chk_historial_descripcion CHECK (CHAR_LENGTH(TRIM(descripcion)) > 0)
);

-- =========================================================
-- 9. ÍNDICES
-- =========================================================
CREATE INDEX idx_usuarios_correo ON usuarios(correo);
CREATE INDEX idx_notas_usuario_id ON notas(usuario_id);
CREATE INDEX idx_notas_categoria_id ON notas(categoria_id);
CREATE INDEX idx_notas_titulo ON notas(titulo);
CREATE INDEX idx_notas_estado ON notas(estado);
CREATE INDEX idx_notas_prioridad ON notas(prioridad);
CREATE INDEX idx_recordatorios_fecha ON recordatorios(fecha_recordatorio);

-- =========================================================
-- 10. DATOS INICIALES: usuarios
-- =========================================================
INSERT INTO usuarios (nombre, apellido, correo, clave, telefono, documento, estado) VALUES
('Luis', 'Pérez', 'luis.perez@gmail.com', '123456', '3001234567', '1001001001', 'ACTIVO'),
('María', 'Gómez', 'maria.gomez@gmail.com', '123456', '3002345678', '1001001002', 'ACTIVO'),
('Carlos', 'Ramírez', 'carlos.ramirez@gmail.com', '123456', '3003456789', '1001001003', 'ACTIVO');

-- =========================================================
-- 11. DATOS INICIALES: categorias
-- =========================================================
INSERT INTO categorias (nombre, descripcion, color, estado) VALUES
('Personal', 'Notas de uso personal', '#3498db', 'ACTIVA'),
('Estudio', 'Notas relacionadas con clases y tareas', '#2ecc71', 'ACTIVA'),
('Trabajo', 'Notas de actividades laborales', '#f39c12', 'ACTIVA'),
('Recordatorios', 'Notas para recordar eventos importantes', '#e74c3c', 'ACTIVA'),
('Ideas', 'Notas rápidas de ideas o pendientes', '#9b59b6', 'ACTIVA');

-- =========================================================
-- 12. DATOS INICIALES: etiquetas
-- =========================================================
INSERT INTO etiquetas (nombre, color) VALUES
('Urgente', '#e74c3c'),
('Importante', '#f1c40f'),
('Pendiente', '#3498db'),
('Finalizado', '#2ecc71'),
('Universidad', '#9b59b6'),
('Casa', '#1abc9c');

-- =========================================================
-- 13. DATOS INICIALES: notas
-- =========================================================
INSERT INTO notas (usuario_id, categoria_id, titulo, contenido, prioridad, estado) VALUES
(1, 1, 'Comprar útiles', 'Debo comprar cuadernos, esferos y resaltadores este fin de semana.', 'MEDIA', 'ACTIVA'),
(1, 2, 'Estudiar POO', 'Repasar abstracción, encapsulamiento, herencia y polimorfismo para el proyecto.', 'ALTA', 'ACTIVA'),
(2, 3, 'Reunión de trabajo', 'Preparar los puntos a tratar en la reunión del lunes con el equipo.', 'ALTA', 'ACTIVA'),
(2, 5, 'Idea para interfaz', 'Agregar colores por categoría y botón de búsqueda de notas.', 'MEDIA', 'ACTIVA'),
(3, 4, 'Pagar recibo', 'No olvidar pagar el recibo del internet antes del día 20.', 'ALTA', 'ARCHIVADA'),
(3, 1, 'Lista del mercado', 'Comprar arroz, leche, huevos, pan y frutas.', 'BAJA', 'ACTIVA');

-- =========================================================
-- 14. DATOS INICIALES: relación notas - etiquetas
-- =========================================================
INSERT INTO nota_etiqueta (nota_id, etiqueta_id) VALUES
(1, 6),
(2, 1),
(2, 5),
(3, 2),
(3, 3),
(4, 5),
(5, 1),
(6, 6);

-- =========================================================
-- 15. DATOS INICIALES: recordatorios
-- =========================================================
INSERT INTO recordatorios (nota_id, fecha_recordatorio, mensaje, estado) VALUES
(1, '2026-05-20 09:00:00', 'Comprar útiles antes del lunes', 'PENDIENTE'),
(2, '2026-05-18 18:00:00', 'Repasar conceptos de POO', 'PENDIENTE'),
(5, '2026-05-19 08:00:00', 'Pagar recibo de internet', 'PENDIENTE');

-- =========================================================
-- 16. DATOS INICIALES: historial_notas
-- =========================================================
INSERT INTO historial_notas (nota_id, accion, descripcion) VALUES
(1, 'CREACION', 'Se creó la nota Comprar útiles'),
(2, 'CREACION', 'Se creó la nota Estudiar POO'),
(3, 'CREACION', 'Se creó la nota Reunión de trabajo'),
(4, 'CREACION', 'Se creó la nota Idea para interfaz'),
(5, 'CREACION', 'Se creó la nota Pagar recibo'),
(5, 'ARCHIVADO', 'La nota fue archivada por el usuario'),
(6, 'CREACION', 'Se creó la nota Lista del mercado');

-- =========================================================
-- 17. ELIMINAR VISTAS SI EXISTEN
-- =========================================================
DROP VIEW IF EXISTS vista_notas_completas;
DROP VIEW IF EXISTS vista_recordatorios_pendientes;

-- =========================================================
-- 18. VISTA: notas completas
-- =========================================================
CREATE VIEW vista_notas_completas AS
SELECT
    n.id,
    n.titulo,
    n.contenido,
    n.prioridad,
    n.estado,
    n.fecha_creacion,
    n.fecha_actualizacion,
    u.id AS usuario_id,
    u.nombre AS nombre_usuario,
    u.apellido AS apellido_usuario,
    u.correo,
    c.id AS categoria_id,
    c.nombre AS categoria,
    c.color AS color_categoria
FROM notas n
INNER JOIN usuarios u ON n.usuario_id = u.id
INNER JOIN categorias c ON n.categoria_id = c.id;

-- =========================================================
-- 19. VISTA: recordatorios pendientes
-- =========================================================
CREATE VIEW vista_recordatorios_pendientes AS
SELECT
    r.id,
    r.nota_id,
    n.titulo AS nota,
    r.fecha_recordatorio,
    r.mensaje,
    r.estado
FROM recordatorios r
INNER JOIN notas n ON r.nota_id = n.id
WHERE r.estado = 'PENDIENTE';

-- =========================================================
-- 20. ELIMINAR PROCEDIMIENTOS SI EXISTEN
-- =========================================================
DROP PROCEDURE IF EXISTS sp_listar_notas;
DROP PROCEDURE IF EXISTS sp_buscar_notas_por_usuario;
DROP PROCEDURE IF EXISTS sp_crear_nota;
DROP PROCEDURE IF EXISTS sp_editar_nota;
DROP PROCEDURE IF EXISTS sp_eliminar_nota_logica;

-- =========================================================
-- 21. PROCEDIMIENTOS ALMACENADOS
-- =========================================================
DELIMITER $$

CREATE PROCEDURE sp_listar_notas()
BEGIN
    SELECT * FROM vista_notas_completas;
END $$

CREATE PROCEDURE sp_buscar_notas_por_usuario(IN p_usuario_id INT)
BEGIN
    SELECT *
    FROM vista_notas_completas
    WHERE usuario_id = p_usuario_id;
END $$

CREATE PROCEDURE sp_crear_nota(
    IN p_usuario_id INT,
    IN p_categoria_id INT,
    IN p_titulo VARCHAR(150),
    IN p_contenido TEXT,
    IN p_prioridad VARCHAR(10)
)
BEGIN
    INSERT INTO notas (
        usuario_id,
        categoria_id,
        titulo,
        contenido,
        prioridad,
        estado
    )
    VALUES (
        p_usuario_id,
        p_categoria_id,
        p_titulo,
        p_contenido,
        p_prioridad,
        'ACTIVA'
    );
END $$

CREATE PROCEDURE sp_editar_nota(
    IN p_id INT,
    IN p_categoria_id INT,
    IN p_titulo VARCHAR(150),
    IN p_contenido TEXT,
    IN p_prioridad VARCHAR(10),
    IN p_estado VARCHAR(15)
)
BEGIN
    UPDATE notas
    SET categoria_id = p_categoria_id,
        titulo = p_titulo,
        contenido = p_contenido,
        prioridad = p_prioridad,
        estado = p_estado
    WHERE id = p_id;
END $$

CREATE PROCEDURE sp_eliminar_nota_logica(IN p_id INT)
BEGIN
    UPDATE notas
    SET estado = 'ELIMINADA'
    WHERE id = p_id;
END $$

DELIMITER ;

-- =========================================================
-- 22. CONSULTAS DE PRUEBA
-- =========================================================

-- Ver usuarios
SELECT * FROM usuarios;

-- Ver categorías
SELECT * FROM categorias;

-- Ver etiquetas
SELECT * FROM etiquetas;

-- Ver notas
SELECT * FROM notas;

-- Ver relación nota-etiqueta
SELECT * FROM nota_etiqueta;

-- Ver recordatorios
SELECT * FROM recordatorios;

-- Ver historial
SELECT * FROM historial_notas;

-- Ver notas completas
SELECT * FROM vista_notas_completas;

-- Ver recordatorios pendientes
SELECT * FROM vista_recordatorios_pendientes;

-- Ejecutar procedimientos
CALL sp_listar_notas();
CALL sp_buscar_notas_por_usuario(1);